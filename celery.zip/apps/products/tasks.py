import random
from faker import Faker
from celery import shared_task, Celery

from .models import Product
from faker_commerce import Provider

fake = Faker()
fake.add_provider(Provider)

app = Celery('products')

@app.task
def create_product():
    for _ in range(10):
      product = Product.objects.create(
        name=fake.ecommerce_name(),
        description=fake.text(),
        price=round(random.uniform(10.0, 100.0), 2))
      print(f"{product.name} has been created")